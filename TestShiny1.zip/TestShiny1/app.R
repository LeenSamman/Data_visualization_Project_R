#it might be said:

# Install and load necessary libraries
if (!requireNamespace("rnaturalearth", quietly = TRUE)) install.packages("rnaturalearth")
if (!requireNamespace("sf", quietly = TRUE)) install.packages("sf")
if (!requireNamespace("ggplot2", quietly = TRUE)) install.packages("ggplot2")
if (!requireNamespace("cartogram", quietly = TRUE)) install.packages("cartogram")



library(shiny)
library(rnaturalearth)
library(sf)
library(ggplot2)
library(dplyr)
library(cartogram)
library(readxl)
library(ggalluvial)
library(forcats)
library(tidyr)


# Load the dataset using readxl
data <- read_excel("FinalDataDV.xlsx", sheet = 1)

# Confirm it is a data frame
data <- as.data.frame(data)




#################################################################
library(sf)
library(rnaturalearth)
library(ggplot2)

# Load world map
world <- ne_countries(scale = "medium", returnclass = "sf")
ggplot(data = world) +
  geom_sf() +
  labs(title = "Test Map")

# Map nationality codes to country names
nationality_mapping <- data.frame(
  Nacionality = c(
    "Portuguese", "German", "Spanish", "Italian", "Dutch", "English", "Lithuanian", 
    "Angolan", "Cape Verdean", "Guinean", "Mozambican", "Santomean", "Turkish", 
    "Brazilian", "Romanian", "Moldova (Republic of)", "Mexican", "Ukrainian", 
    "Russian", "Cuban", "Colombian"
  ),
  Country = c(
    "Portugal", "Germany", "Spain", "Italy", "Netherlands", "United Kingdom", "Lithuania", 
    "Angola", "Cabo Verde", "Guinea-Bissau", "Mozambique", "Sao Tome and Principe", "Turkey", 
    "Brazil", "Romania", "Moldova", "Mexico", "Ukraine", 
    "Russia", "Cuba", "Colombia"
  )
)


################################

# Clean up column names to replace spaces and special characters with underscores
colnames(data) <- gsub(" ", "_", colnames(data))  # Replace spaces with underscores
colnames(data) <- gsub("/", "_", colnames(data))  # Replace slashes with underscores

# Check the cleaned column names to verify everything is correct
print(colnames(data))  # Ensure correct column names

# Rename columns if necessary (adjusting as needed)
colnames(data)[colnames(data) == "Daytime_evening_attendance"] <- "attendance_status"
colnames(data)[colnames(data) == "Target_Column"] <- "Target"  # Ensure 'Target' is correctly named
colnames(data)[colnames(data) == "Age_at_enrollment_Column"] <- "Age_at_enrollment"  # Ensure 'Age_at_enrollment' is correctly named

# Verify the column names and unique values in the renamed columns
print(unique(data$attendance_status))  # Ensure it's correctly formatted
print(unique(data$Target))  # Check unique values in the 'Target' column
print(summary(data$Age_at_enrollment))  # Check the summary of 'Age_at_enrollment' to ensure it's numeric

# Ensure 'attendance_status' is a factor (if not, convert it)
data$attendance_status <- as.factor(data$attendance_status)

# Ensure 'Target' is a factor (if not, convert it)
data$Target <- as.factor(data$Target)

# Ensure 'Age_at_enrollment' is numeric (if not, convert it)
data$Age_at_enrollment <- as.numeric(data$Age_at_enrollment)

# Check for missing values or extreme outliers in 'Age_at_enrollment'
summary(data$Age_at_enrollment)  # Ensure there are no missing or incorrect values

# Remove rows with missing values in important columns (optional)
data <- data %>%
  filter(!is.na(Age_at_enrollment), !is.na(Target), !is.na(attendance_status))




# Ensure that the dataset is correctly defined
attendance_counts <- data %>%
  group_by(attendance_status) %>%
  summarise(Count = n()) %>%
  mutate(Percentage = round(Count / sum(Count) * 100)) %>%
  ungroup()

# Check if the data looks correct
print(attendance_counts)







####################################################################
# Reactive data for 1st Semester Performance Distribution
firstSemData <- reactive({
  data %>%
    group_by(Course, First_Sem_Performance) %>%  # Adjust grouping as per your dataset
    summarise(Count = n(), .groups = "drop")  # Compute counts
})

# Reactive data for 2nd Semester Performance Distribution
secondSemData <- reactive({
  data %>%
    group_by(Course, Second_Sem_Performance) %>%  # Adjust grouping as per your dataset
    summarise(Count = n(), .groups = "drop")  # Compute counts
})


######################################################################

######################################################################
# Reactive expression to read and process the uploaded data

# Define custom colors for performance levels
custom_colors <- c(
  "Failing" = "#C96868",  # Red
  "Passing" = "#D3F1DF",  # Yellow
  "Good" = "#85A98F",     # Green
  "Excellent" = "#5A6C57" # Blue
)
processed_data <- reactive({
  req(data())  # Ensure data is available
  
  # Check if necessary columns exist in the data
  if(!all(c("Curricular units 1st sem (grade)", "Application mode") %in% colnames(data()))) {
    showModal(modalDialog(
      title = "Error",
      "The necessary columns ('Curricular units 1st sem (grade)', 'Application mode') are missing in the uploaded file.",
      easyClose = TRUE,
      footer = NULL
    ))
    return(NULL)  # If columns are missing, stop processing
  }
  
  # Add performance classification based on grades
  data() %>%
    mutate(
      First_Sem_Performance = case_when(
        `Curricular units 1st sem (grade)` < 10 ~ "Failing",
        `Curricular units 1st sem (grade)` >= 10 & `Curricular units 1st sem (grade)` < 12 ~ "Passing",
        `Curricular units 1st sem (grade)` >= 12 & `Curricular units 1st sem (grade)` < 15 ~ "Good",
        `Curricular units 1st sem (grade)` >= 15 & `Curricular units 1st sem (grade)` <= 20 ~ "Excellent",
        TRUE ~ NA_character_
      )
    ) %>%
    mutate(
      First_Sem_Performance = factor(
        First_Sem_Performance,
        levels = c("Excellent", "Good", "Passing", "Failing")
      )
    )
})
############################################################################################################


# UI layout
ui <- fluidPage(
  div(class = "title-panel", "Student Dropout Analysis"),
  
  # Define the main tab panel with 'Nationality' tab and other existing tabs
  tabsetPanel(
    id = "main_tabs",
    

    
    
    
    
    # Rectangles Tab
    tabPanel(
      "Stack Bars",
      tabsetPanel(   # Nested tabsetPanel for the 7 tabs inside "Stack Bars"
        id = "rectangles_tabs",
        
        # Tab 1: Tuition Fees Status Plot
        tabPanel(
          "Tuition Fees Status",
          mainPanel(
            plotOutput("tuitionPlot", width = "100%", height = "600px")
          )
        ),
        
        # Tab 2: Scholarship Distribution Plot
        tabPanel(
          "Scholarship",
          mainPanel(
            plotOutput("scholarshipPlot", width = "100%", height = "600px")
          )
        ),
        
        # Tab 3: Attendance Distribution Plot
        tabPanel(
          "Attendance",
          mainPanel(
            plotOutput("attendancePlot", width = "100%", height = "600px")
          )
        ),
        
        # Tab 4: Debtor Status
        tabPanel(
          "Debtor Status",
          mainPanel(
            plotOutput("debtorPlot", width = "100%", height = "600px")
          )
        ),
        
        # Tab 5: International Status
        tabPanel(
          "International Status",
          mainPanel(
            plotOutput("internationalPlot", width = "100%", height = "600px")
          )
        ),
        
        # Tab 6: Educational Special Needs
        tabPanel(
          "Educational Special Needs",
          mainPanel(
            plotOutput("specialNeedsPlot", width = "100%", height = "600px")
          )
        ),
        
        # Tab 7: Gender Distribution (Ordered)
        tabPanel(
          "Gender Distribution (Ordered)",
          mainPanel(
            plotOutput("genderOrderedPlot", width = "100%", height = "600px"),
            verbatimTextOutput("debugGenderData")  # Debugging output (optional)
          )
        )
      )
    )
    ,
    
    # Group bars tab
    tabPanel("Group Bars",
             tabsetPanel(
               id = "group_bars_tabs",
               
               # Tab 1: Target Counts by Gender
               tabPanel("Target Counts by Gender",
                        mainPanel(
                          plotOutput("groupBarsPlot", width = "1000px", height = "600px")
                        )
               ),
               
               # Tab 2: Scholarship Holders by Target
               tabPanel("Scholarship Holders by Target",
                        mainPanel(
                          plotOutput("scholarshipBarsPlot", width = "1000px", height = "600px")
                        )
               )
             )
    ),
    
    
    
    
    # Box Plot Tab with two nested tabs
    tabPanel("Box Plots",
             tabsetPanel(   # Nested tabsetPanel for the 2 tabs inside Box Plot
               id = "boxplot_tabs",
               
               # Tab 1: Grade Distribution by Target
               tabPanel("Grade Distribution",
                        mainPanel(
                          plotOutput("boxPlot", width = "1000px", height = "600px")
                        )
               ),
               
               # Tab 2: Age at Enrollment by Target
               tabPanel("Age at Enrollment",
                        mainPanel(
                          plotOutput("ageBoxPlot", width = "1000px", height = "600px")
                        )
               )
             )
    ),
    
    # Histogram Tab with two nested subtabs
    tabPanel("Bar Plots",
             tabsetPanel(   # Nested tabsetPanel for the subtabs inside Histogram
               id = "histogram_tabs",
               
            
               # Subtab 1: Daytime vs Evening Attendance Plot
               tabPanel("Attendance Histogram",
                        mainPanel(
                          plotOutput("attendancePlot1", width = "1000px", height = "600px")
                        )
               )
             )
    ),
    

    # Performance Tab with nested tabs
    tabPanel(
      "Performance Plots",
      tabsetPanel(  # Nested tabsetPanel for the 4 tabs inside Performance
        id = "performance_tabs",
        
        # Tab 1: 1st Semester with nested tabs
        tabPanel(
          "1st Semester",
          tabsetPanel(
            # Subtab: Performance Categories 1
            tabPanel(
              "Performance Categories 1",
              mainPanel(
                plotOutput("originalCategoriesPlot", width = "1000px", height = "600px")
              )
            ),
            
            # Subtab: Performance Distribution 1
            tabPanel(
              "Performance Distribution 1",
              mainPanel(
                plotOutput("firstSemPlot", width = "1000px", height = "600px")
              )
            )
          )
        ),
        
        # Tab 2: 2nd Semester with nested tabs
        tabPanel(
          "2nd Semester",
          tabsetPanel(
            # Subtab: Performance Categories 2
            tabPanel(
              "Performance Categories 2",
              mainPanel(
                plotOutput("secondSemPlot", width = "1000px", height = "600px")
              )
            ),
            
            # Subtab: Performance Distribution 2
            tabPanel(
              "Performance Distribution 2",
              mainPanel(
                plotOutput("performanceDistribution2Plot", width = "1000px", height = "600px")
              )
            )
          )
        )
      )
    )
    
     ,
    
    # Cumulative Tab with nested tabs for 1st and 2nd Semesters, plus Grade Distributions
    tabPanel("Cumulative",
             tabsetPanel(
               id = "cumulative_tabs",
               
               # Tab 1: 1st Semester
               tabPanel("1st Semester",
                        tabsetPanel(
                          # Subtab 1: Cumulative Frequency 1
                          tabPanel("Cumulative Frequency 1",
                                   mainPanel(
                                     plotOutput("cumulativeFirstSemPlot", width = "1000px", height = "600px")
                                   )
                          ),
                          
                          # Subtab 2: QQ Plot 1 (Placeholder for future)
                          tabPanel("QQ Plot 1",
                                   mainPanel(
                                     plotOutput("qqFirstSemPlot", width = "1000px", height = "600px")
                                   )
                          )
                        )
               ),
               
               # Tab 2: 2nd Semester
               tabPanel("2nd Semester",
                        tabsetPanel(
                          # Subtab 1: Cumulative Frequency 2
                          tabPanel("Cumulative Frequency 2",
                                   mainPanel(
                                     plotOutput("cumulativeSecondSemPlot", width = "1000px", height = "600px")
                                   )
                          ),
                          
                          # Subtab 2: QQ Plot 2 (Placeholder for future)
                          tabPanel("QQ Plot 2",
                                   mainPanel(
                                     plotOutput("qqSecondSemPlot", width = "1000px", height = "600px")
                                   )
                          )
                        )
               ),
               
               # Tab 3: Grade Distributions (Placeholder for future)
               tabPanel("Grade Distributions",
                        mainPanel(
                          plotOutput("gradeDistributionPlot", width = "1000px", height = "600px")
                        )
               )
             )
    )
    ,
    
    # Nationality Tab with four nested tabs
    # Nationality Tab with four nested tabs
    tabPanel(
      "Nationality Plots",
      tabsetPanel(   # Nested tabsetPanel for the 4 tabs inside Nationality
        id = "nationality_tabs",
        
        # Tab 1: Performance Evaluation
        tabPanel(
          "Performance Evaluation",
          mainPanel(
            plotOutput("performanceEvaluationPlot", width = "1000px", height = "600px")
          )
        ),
        
        # Tab 2: Global Distribution
        tabPanel(
          "Global Distribution",
          mainPanel(
            plotOutput("globalDistributionPlot", width = "1000px", height = "600px")
          )
        ),
        
        # Tab 3: Number of Students
        tabPanel(
          "Number of Students",
          mainPanel(
            plotOutput("numberOfStudentsPlot", width = "1000px", height = "600px"),
            plotOutput("topNationalitiesPlot", width = "1000px", height = "600px")
          )
        ),
        
        # Tab 4: Target Distribution
        tabPanel(
          "Target Distribution",
          mainPanel(
            plotOutput("targetDistributionPlot", width = "1000px", height = "600px")
          )
        )
      )
    )
    ,
    
    
    # Parallel Tab
    tabPanel("Parallel Sets",
             mainPanel(
               plotOutput("parallelPlot", width = "1000px", height = "600px"),
               verbatimTextOutput("debugData")  # Display debug output
             )
             
    ),
    
    
    tabPanel(
      "Uncertainty",  # Main Uncertainty Tab
      tabsetPanel(
        id = "uncertainty_tabs",
        
        # Sub-tab for "Nationality vs Mean Grades"
        tabPanel(
          "Nationality vs Mean Grades",
          tabsetPanel(
            id = "grades_tabs",
            
            # Tab for 1st Semester
            tabPanel(
              "1st Semester",
              mainPanel(
                plotOutput("uncertaintyFirstSemPlot", width = "1000px", height = "600px")
              )
            ),
            
            # Tab for 2nd Semester
            tabPanel(
              "2nd Semester",
              mainPanel(
                plotOutput("uncertaintySecondSemPlot", width = "1000px", height = "600px")
              )
            )
          )
        ),
        
        # New Sub-tab for Semester Performance Grids
        tabPanel(
          "Semester Performance Grids",
          tabsetPanel(
            id = "performance_grid_tabs",
            
            # First Semester Performance Grid Tab
            tabPanel(
              "First Semester Grid",
              mainPanel(
                plotOutput("firstSemGridPlot", width = "1000px", height = "600px")
              )
            ),
            
            # Second Semester Performance Grid Tab
            tabPanel(
              "Second Semester Grid",
              mainPanel(
                plotOutput("secondSemGridPlot", width = "1000px", height = "600px")
              )
            )
          )
        )
      )
    )
    
    
         ,
    #hereeeee
    
    
    
    tabPanel("Data Columns",
             mainPanel(
               verbatimTextOutput("debugColumns")  # Display column names
             )
    ),
  ),

  
  
  # Add custom CSS to adjust margins
  tags$style(HTML("
    /* Import Google Font */
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');
    
    /* Apply Font to the Body */
    body {
        font-family: 'Poppins', sans-serif; /* Change font */
        background-color: #F4F7F3; /* Subtle greenish-gray background */
        color: #2E3B2F; /* Deep forest green text */
        margin: 0;
        padding: 0;
    }
    
    .plot-container {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 20px; /* Add space above the plot */
        margin-bottom: 20px; /* Add space below the plot */
    }

    /* Navbar */
    .navbar-default {
        background-color: #DFF0D8; /* Light green background */
        border-bottom: 2px solid #85A98F; /* Medium green border */
    }

    .navbar-default .navbar-brand {
        color: #4C704C !important; /* Warm green for brand text */
        font-size: 22px;
    }

    .navbar-default .navbar-nav > li > a {
        color: #4C704C; /* Warm green for nav links */
        font-weight: bold;
    }

    .navbar-default .navbar-nav > li.active > a {
        background-color: #85A98F !important; /* Active tab background */
        color: #FFFFFF !important; /* White active tab text */
    }

    /* Tab Styling */
    .tabbable > .nav > li > a {
        background-color: #E9F4EB; /* Very light green tab background */
        color: #4C704C; /* Warm green text */
        border-radius: 5px;
    }

    .tabbable > .nav > li.active > a {
        background-color: #85A98F !important; /* Medium green active tab */
        color: #FFFFFF !important; /* White text on active tab */
    }

    /* Buttons */
    .btn {
        background-color: #85A98F; /* Warm green button background */
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 14px;
        padding: 10px 20px;
        cursor: pointer;
    }

    .btn:hover {
        background-color: #6D8F6D; /* Darker warm green on hover */
    }

    /* Panels and Main Area */
    .main-panel {
        padding: 20px;
        background-color: #F8FAF5; /* Light greenish background for panels */
        border-radius: 10px;
    }

    .well {
        background-color: #DCE8D4; /* Soft green sidebar */
        border: 1px solid #A3C4A8; /* Medium green border */
        border-radius: 8px;
    }

    /* Footer */
    footer {
        text-align: center;
        padding: 10px;
        background-color: #85A98F; /* Footer in warm green */
        color: white;
        font-size: 12px;
    }
    
     .title-panel {
        background-color: #85A98F; /* Warm green background */
        color: white; /* White text */
        padding: 20px 15px; /* Add padding */
        border-radius: 10px; /* Rounded corners */
        font-family: 'Poppins', sans-serif; /* Change font */
        font-size: 28px; /* Larger font size for the title */
        text-align: center; /* Center the text */
        font-weight: bold; /* Make the title bold */
        margin-bottom: 20px; /* Add space below the title */
    }

    /* Subsection Headings */
    h2, h3 {
        color: #4C704C; /* Deep warm green */
        font-family: 'Arial', sans-serif;
        font-weight: bold;
        margin-top: 20px;
    }

    /* Subheading Underlines */
    h2::after, h3::after {
        content: '';
        display: block;
        width: 50px;
        height: 3px;
        background-color: #85A98F; /* Warm green underline */
        margin: 5px auto; /* Center the underline */
    }
    
"))
  
)





######################################################################

# Server logic
server <- function(input, output) {
  
  # Tuition Fees Status Plot
  tuition_plot <- reactive({
    data %>%
      group_by(Tuition_fees_up_to_date, Target) %>%
      summarise(Count = n(), .groups = 'drop') %>%
      group_by(Tuition_fees_up_to_date) %>%
      mutate(Percentage = round((Count / sum(Count)) * 100)) %>%
      ungroup()
  })
  
  output$tuitionPlot <- renderPlot({
    ggplot(tuition_plot(), aes(x = Percentage, y = Tuition_fees_up_to_date, fill = Target)) +
      geom_bar(stat = "identity", position = "stack", width = 0.95) +
      geom_text(
        aes(
          label = paste0(Percentage, "%"),
          color = ifelse(Target == "Dropout", "black", "white")
        ),
        position = position_stack(vjust = 0.5),
        size = 3.5
      ) +
      labs(
        title = "Distribution by Tuition Fees Status",
        x = "Percentage",
        y = "Tuition Fees Status"
      ) +
      scale_fill_manual(
        values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F"),
        name = "Target"
      ) +
      scale_color_identity() +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text = element_text(size = 10),
        axis.title = element_text(size = 12),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12),
        panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank()
      )
  })


  #######################################################################
  output$debugColumns <- renderPrint({
    colnames(data)  # Display column names of your dataset
  })
  
  #####################################################################
  
  # Reactive data for Gender Distribution
  genderTargetCounts <- reactive({
    data %>%
      group_by(Target, Gender) %>%
      summarise(Count = n(), .groups = 'drop') %>%
      group_by(Target) %>%
      mutate(Total = sum(Count)) %>%
      ungroup() %>%
      mutate(Target = fct_reorder(Target, Total, .desc = TRUE)) # Reorder Target
  })
  
  # Render the plot
  output$genderOrderedPlot <- renderPlot({
    ggplot(genderTargetCounts(), aes(x = Target, y = Count, fill = Gender)) +
      geom_bar(stat = "identity") +
      geom_text(aes(label = Count), position = position_stack(vjust = 0.5), color = "white") +
      scale_fill_manual(values = c("Male" = "#85A98F", "Female" = "#FDCEDF")) +
      labs(
        title = "Gender Distribution by Target Categories (Ordered)",
        x = "Target",
        y = "Count",
        fill = "Gender"
      ) +
      theme_minimal()
  })
  
  # Optional: Debugging output
  output$debugGenderData <- renderPrint({
    genderTargetCounts()
  })
  
  #####################################################################
  special_needs_plot <- reactive({
    data %>%
      group_by(Educational_special_needs, Target) %>%
      summarise(Count = n(), .groups = 'drop') %>%
      group_by(Educational_special_needs) %>%
      mutate(Percentage = round((Count / sum(Count)) * 100)) %>%
      ungroup()
  })
  output$specialNeedsPlot <- renderPlot({
    ggplot(special_needs_plot(), aes(x = Percentage, y = Educational_special_needs, fill = Target)) +
      geom_bar(stat = "identity", position = "stack", width = 0.95) +
      geom_text(
        aes(
          label = paste0(Percentage, "%"),
          color = ifelse(Target == "Dropout", "black", "white") # Conditional text color
        ),
        position = position_stack(vjust = 0.5), # Center the text vertically in the box
        size = 3.5
      ) +
      labs(
        title = "Distribution by Educational Special Needs",
        x = "Percentage",
        y = "Educational Special Needs"
      ) +
      scale_fill_manual(
        values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F"),
        name = "Target"
      ) +
      scale_color_identity() + # Use specified text colors directly
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text = element_text(size = 10),
        axis.title = element_text(size = 12),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12),
        panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank()
      )
  })
  
  
  ######################################################################
  genderTargetCounts <- reactive({
    req(data)  # Ensure data is available
    data %>%
      group_by(Target, Gender) %>%
      summarise(Count = n(), .groups = 'drop') %>%
      group_by(Target) %>%
      mutate(Total = sum(Count)) %>%
      ungroup() %>%
      mutate(Target = forcats::fct_reorder(Target, Total, .desc = TRUE))  # Reorder Target
  })
  
  
  
  output$genderOrderedPlot <- renderPlot({
    req(genderTargetCounts())  # Ensure the reactive function outputs data
    ggplot(genderTargetCounts(), aes(x = Target, y = Count, fill = Gender)) +
      geom_bar(stat = "identity") +
      geom_text(aes(label = Count), position = position_stack(vjust = 0.5), color = "white") +
      scale_fill_manual(values = c("Male" = "#85A98F", "Female" = "#FDCEDF")) +
      labs(
        title = "Gender Distribution by Target Categories (Ordered)",
        x = "Target",
        y = "Count",
        fill = "Gender"
      ) +
      theme_minimal()
  })
  
  
  
  ######################################################################
  international_plot <- reactive({
    data %>%
      group_by(International, Target) %>%
      summarise(Count = n(), .groups = 'drop') %>%
      group_by(International) %>%
      mutate(Percentage = round((Count / sum(Count)) * 100)) %>%
      ungroup()
  })
  output$internationalPlot <- renderPlot({
    ggplot(international_plot(), aes(x = Percentage, y = International, fill = Target)) +
      geom_bar(stat = "identity", position = "stack", width = 0.95) +
      geom_text(
        aes(
          label = paste0(Percentage, "%"),
          color = ifelse(Target == "Dropout", "black", "white") # Conditional text color
        ),
        position = position_stack(vjust = 0.5), # Center the text vertically in the box
        size = 3.5
      ) +
      labs(
        title = "Distribution by International Status",
        x = "Percentage",
        y = "International Status"
      ) +
      scale_fill_manual(
        values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F"),
        name = "Target"
      ) +
      scale_color_identity() + # Use specified text colors directly
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text = element_text(size = 10),
        axis.title = element_text(size = 12),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12),
        panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank()
      )
  })
  
  ######################################################################
  
  groupBarsData <- reactive({
    data %>%
      group_by(Target, Gender) %>%
      summarise(Count = n(), .groups = "drop") %>%
      mutate(Percentage = Count / sum(Count) * 100)
  })
  
  output$groupBarsPlot <- renderPlot({
    ggplot(groupBarsData(), aes(x = reorder(Target, -Count), y = Count, fill = Gender)) +
      geom_bar(stat = "identity", position = "dodge") +
      scale_fill_manual(
        values = c("Male" = "#85A98F", "Female" = "#FDCEDF"),  # Map Gender values to colors
        labels = c("Male" = "Male", "Female" = "Female")  # Ensure labels are correct
      ) +
      labs(
        title = "Target Counts by Gender",
        x = "Target",
        y = "Count",
        fill = "Gender"
      ) +
      theme_minimal()
  })
  
  
  
  ######################################################################
  # Reactive Data for Scholarship Holders by Target
  scholarshipData <- reactive({
    data %>%
      group_by(Scholarship_holder, Target) %>%
      summarise(Count = n(), .groups = "drop")  # Summarize actual counts
  })
  
  # Render the Scholarship Holders Plot
  output$scholarshipBarsPlot <- renderPlot({
    ggplot(scholarshipData(), aes(x = as.factor(Scholarship_holder), y = Count, fill = Target)) +
      geom_bar(stat = "identity", position = "dodge") +  # Use "identity" to ensure proper counts
      scale_fill_manual(
        values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F")
      ) +
      labs(
        title = "Scholarship Holders by Target",
        x = "Scholarship Holder",
        y = "Count",
        fill = "Target"
      ) +
      theme_minimal()
  })
  
  
  
  
  
  
  
  ######################################################################
  debtor_plot <- reactive({
    data %>%
      group_by(Debtor, Target) %>%
      summarise(Count = n(), .groups = 'drop') %>%
      group_by(Debtor) %>%
      mutate(Percentage = round((Count / sum(Count)) * 100)) %>%
      ungroup()
  })
  output$debtorPlot <- renderPlot({
    ggplot(debtor_plot(), aes(x = Percentage, y = Debtor, fill = Target)) +
      geom_bar(stat = "identity", position = "stack", width = 0.95) +
      geom_text(
        aes(
          label = paste0(Percentage, "%"),
          color = ifelse(Target == "Dropout", "black", "white") # Conditional text color
        ),
        position = position_stack(vjust = 0.5), # Center the text vertically in the box
        size = 3.5
      ) +
      labs(
        title = "Distribution by Debtor Status",
        x = "Percentage",
        y = "Debtor"
      ) +
      scale_fill_manual(
        values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F"),
        name = "Target"
      ) +
      scale_color_identity() + # Use specified text colors directly
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text = element_text(size = 10),
        axis.title = element_text(size = 12),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12),
        panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank()
      )
  })
  
  ######################################################################
  # Scholarship Distribution Plot
  scholarship_plot <- reactive({
    data %>%
      group_by(Scholarship_holder, Target) %>%
      summarise(Count = n(), .groups = 'drop') %>%
      group_by(Scholarship_holder) %>%
      mutate(Percentage = round((Count / sum(Count)) * 100)) %>%
      ungroup()
  })
  
  output$scholarshipPlot <- renderPlot({
    ggplot(scholarship_plot(), aes(x = Percentage, y = Scholarship_holder, fill = Target)) +
      geom_bar(stat = "identity", position = "stack", width = 0.95) +
      geom_text(
        aes(
          label = paste0(Percentage, "%"),
          color = ifelse(Target == "Dropout", "black", "white")
        ),
        position = position_stack(vjust = 0.5),
        size = 3.5
      ) +
      labs(
        title = "Distribution by Scholarship Status",
        x = "Percentage",
        y = "Scholarship Status"
      ) +
      scale_fill_manual(
        values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F"),
        name = "Target"
      ) +
      scale_color_identity() +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text = element_text(size = 10),
        axis.title = element_text(size = 12),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12),
        panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank()
      )
  })
  ######################################################################  # Attendance Distribution Plot
  attendance_plot <- reactive({
    # Ensure the 'attendance_status' column is used correctly
    data %>%
      group_by(attendance_status, Target) %>%
      summarise(Count = n(), .groups = 'drop') %>%
      group_by(attendance_status) %>%
      mutate(Percentage = round((Count / sum(Count)) * 100)) %>%
      ungroup()
  })
  
  output$attendancePlot <- renderPlot({
    # Print the data for debugging before plotting
    print(attendance_plot())  # Check if the reactive data is correct
    
    ggplot(attendance_plot(), aes(x = Percentage, y = attendance_status, fill = Target)) +
      geom_bar(stat = "identity", position = "stack", width = 0.95) +
      geom_text(
        aes(
          label = paste0(Percentage, "%"),
          color = ifelse(Target == "Dropout", "black", "white")
        ),
        position = position_stack(vjust = 0.5),
        size = 3.5
      ) +
      labs(
        title = "Distribution by Attendance",
        x = "Percentage",
        y = "Attendance"
      ) +
      scale_fill_manual(
        values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F"),
        name = "Target"
      ) +
      scale_color_identity() +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text = element_text(size = 10),
        axis.title = element_text(size = 12),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12),
        panel.grid.minor = element_blank(),
        panel.grid.major.y = element_blank()
      )
  })
  ######################################################################
  # Gender Distribution Plot
  output$genderPlot <- renderPlot({
    ggplot(data, aes(x = Gender, fill = Target)) +
      geom_bar(position = "dodge") +
      labs(title = "Gender Distribution by Target Categories",
           x = "Gender",
           y = "Count") +
      scale_fill_manual(values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F"))
  })
  
#########################################################################################  
  # Define custom colors
  custom_colors <- c(
    "Failing" = "#C96868",  # Red
    "Passing" = "#D3F1DF",  # Yellow
    "Good" = "#85A98F",     # Green
    "Excellent" = "#5A6C57" # Blue
  )
  
  # Render the first semester performance plot
  output$originalCategoriesPlot <- renderPlot({
    ggplot(data, aes(x = First_Sem_Performance, fill = First_Sem_Performance)) +
      geom_bar() +
      scale_fill_manual(values = custom_colors) +  # Use custom colors
      labs(
        title = "Student Performance Categories (First Semester)",
        x = "Performance Level",
        y = "Count",
        fill = "Performance"
      ) +
      coord_cartesian(ylim = c(0, 2500)) +  # Set limits for the y-axis
      theme_minimal() +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 14),
        legend.text = element_text(size = 12),
        legend.title = element_text(size = 14)
      )
  }, height = 400, width = 700)  # Set the plot size
  
  # Render the second semester plot
  output$secondSemPlot <- renderPlot({
    ggplot(data, aes(x = Second_Sem_Performance, fill = Second_Sem_Performance)) +
      geom_bar() +
      scale_fill_manual(values = custom_colors) +  # Use custom colors
      labs(
        title = "Student Performance Categories (Second Semester)",
        x = "Performance Level",
        y = "Count",
        fill = "Performance"
      ) +
      coord_cartesian(ylim = c(0, 2500)) +  # Set limits for the y-axis
      theme_minimal() +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text = element_text(size = 12),
        axis.title = element_text(size = 14),
        legend.text = element_text(size = 12),
        legend.title = element_text(size = 14)
      )
  }, height = 400, width = 700)  # Set the plot size
  
  ######################################################################
  # Age at Enrollment Box Plot
  output$ageBoxPlot <- renderPlot({
    ggplot(data, aes(x = Target, y = Age_at_enrollment, fill = Target)) +
      geom_boxplot() +
      labs(title = "Age at Enrollment by Target", x = "Target", y = "Age at Enrollment") +
      scale_fill_manual(values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F")) +
      theme_minimal()
  })
  
  
  ######################################################################
  # Grades Distribution Plot (Box plot)
  output$boxPlot <- renderPlot({
    ggplot(data, aes(x = Target, y = `Curricular_units_1st_sem_(grade)`, fill = Target)) +
      geom_boxplot(width = 0.5) +  # Adjust box width for a smaller plot
      labs(title = "Grades Distribution by Target", x = "Target", y = "1st Semester Grade") +
      scale_fill_manual(values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F")) +
      theme_minimal() +
      theme(
        axis.text.x = element_text(angle = 0, hjust = 0.5),  # Horizontal x-axis labels
        plot.margin = margin(10, 10, 10, 10),  # Adjust margins for a smaller plot
        axis.title.x = element_text(size = 10),  # Smaller x-axis label size
        axis.title.y = element_text(size = 10),  # Smaller y-axis label size
        plot.title = element_text(size = 14)  # Smaller title size
      )
  })
  # Render the bar plot for Daytime vs Evening Attendance
  output$attendancePlot1 <- renderPlot({
    # Check if attendance_counts has been correctly computed
    print(head(attendance_counts))  # Debugging: Check the first few rows
    
    ggplot(attendance_counts, aes(x = attendance_status, y = Count, fill = attendance_status)) +
      geom_bar(stat = "identity") +
      scale_fill_manual(values = c("Daytime" = "#D3F1DF", "Evening" = "#5A6C57")) +
      labs(title = "Daytime vs Evening Attendance", x = "Attendance", y = "Count") +
      theme_minimal()
  })
  
  
  
  #parallel
  ######################################################################
  # Parallel Set Chart
  output$debugData <- renderPrint({
    # Print the first few rows of the dataset to debug
    head(data %>%
           select(First_Sem_Performance, Second_Sem_Performance, Target) %>%
           na.omit())
  })
  
  output$parallelPlot <- renderPlot({
    # Data preparation for the parallel set chart
    parallel_data <- data %>%
      select(First_Sem_Performance, Second_Sem_Performance, Target) %>%
      na.omit() %>%
      group_by(First_Sem_Performance, Second_Sem_Performance, Target) %>%
      summarise(Count = n(), .groups = "drop")
    
    # Custom colors for performance levels
    custom_colors <- c(
      "Failing" = "#C96868",  # Red
      "Passing" = "#D3F1DF",  # Yellow
      "Good" = "#85A98F",     # Green
      "Excellent" = "#5A6C57" # Blue
    )
    
    # Render the parallel set chart
    ggplot(parallel_data, aes(
      axis1 = First_Sem_Performance,
      axis2 = Second_Sem_Performance,
      axis3 = Target,
      y = Count
    )) +
      geom_alluvium(aes(fill = First_Sem_Performance), width = 1/5) +
      geom_stratum(width = 1/5, fill = "lightgray", color = "black") +
      geom_text(
        stat = "stratum",
        aes(label = after_stat(stratum)),
        angle = 90,
        size = 3.5,
        color = "black",
        hjust = 0.5,
        vjust = 0.5
      ) +
      scale_x_discrete(
        limits = c("1st Sem Performance", "2nd Sem Performance", "Target"),
        expand = c(0.1, 0.1)
      ) +
      scale_fill_manual(values = custom_colors) +
      labs(
        title = "Parallel Set Chart: Performance Flow",
        x = "Stages",
        y = "Count",
        fill = "1st Sem Performance"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 18),
        axis.text.x = element_text(size = 12),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12),
        panel.grid = element_blank(),
        plot.margin = margin(t = 10, r = 10, b = 10)
      )
  })
  
  
  ######################################################################
  # Render the plot for Application Mode & Performance
  output$applicationModePlot <- renderPlot({
    req(processed_data())  # Ensure data is available
    
    ggplot(application_performance(), aes(x = Count, y = Application_mode, fill = First_Sem_Performance)) +
      geom_bar(stat = "identity", position = "fill", width = 0.7) +  # Adjust position to "fill" for full-width bars
      geom_text(
        aes(label = Count),
        position = position_fill(vjust = 0.5),  # Place text in the center of the bars
        color = "white",
        size = 3.5
      ) +
      labs(
        title = "Performance Distribution by Application Mode",
        x = "Proportion",
        y = "Application Mode",
        fill = "Performance"
      ) +
      scale_fill_manual(values = custom_colors) +  # Use custom colors
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12)
      )
  })
  
  
  
  ######################################################################
  #Performance Distribution 1st semester
  output$firstSemPlot <- renderPlot({
    ggplot(firstSemData(), aes(x = Count, y = Course, fill = First_Sem_Performance)) +
      geom_bar(stat = "identity", position = "fill", width = 0.7) +
      geom_text(
        aes(label = Count),
        position = position_fill(vjust = 0.5),
        color = "white",
        size = 3.5
      ) +
      labs(
        title = "Performance Distribution by Course (1st Semester)",
        x = "Proportion",
        y = "Course",
        fill = "Performance"
      ) +
      scale_fill_manual(
        values = c("Failing" = "#C96868",
                   "Passing" = "#D3F1DF",
                   "Good" = "#85A98F",
                   "Excellent" = "#5A6C57")
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12)
      )
  })
  
  
  ######################################################################
  output$performanceDistribution2Plot <- renderPlot({
    ggplot(secondSemData(), aes(x = Count, y = Course, fill = Second_Sem_Performance)) +
      geom_bar(stat = "identity", position = "fill", width = 0.7) +
      geom_text(
        aes(label = Count),
        position = position_fill(vjust = 0.5),
        color = "white",
        size = 3.5
      ) +
      labs(
        title = "Performance Distribution by Course (2nd Semester)",
        x = "Proportion",
        y = "Course",
        fill = "Performance"
      ) +
      scale_fill_manual(
        values = c("Failing" = "#C96868",
                   "Passing" = "#D3F1DF",
                   "Good" = "#85A98F",
                   "Excellent" = "#5A6C57")
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12)
      )
  })
##############################################################################
  processedData <- reactive({
    req(data) # Ensure data is available
    data %>%
      mutate(
        `Curricular_units_1st_sem_(grade)` = as.numeric(`Curricular_units_1st_sem_(grade)`),
        `Curricular_units_2nd_sem_(grade)` = as.numeric(`Curricular_units_2nd_sem_(grade)`)
      ) %>%
      filter(
        `Curricular_units_1st_sem_(grade)` >= 0,
        `Curricular_units_2nd_sem_(grade)` >= 0
      )
  })
  
  # Render plot for the first semester cumulative frequency
  output$cumulativeFirstSemPlot <- renderPlot({
    ggplot(processedData(), aes(x = `Curricular_units_1st_sem_(grade)`)) +
      stat_ecdf(geom = "step", color = "#355F2E", size = 1) +
      labs(
        title = "Cumulative Frequency of First Semester Grades",
        x = "Grade (Out of 20)",
        y = "Cumulative Frequency"
      ) +
      scale_x_continuous(limits = c(0, 20), expand = c(0, 0)) +
      theme_minimal(base_size = 15)
  })
  
  # Render plot for the second semester cumulative frequency
  output$cumulativeSecondSemPlot <- renderPlot({
    ggplot(processedData(), aes(x = `Curricular_units_2nd_sem_(grade)`)) +
      stat_ecdf(geom = "step", color = "#355F2E", size = 1) +
      labs(
        title = "Cumulative Frequency of Second Semester Grades",
        x = "Grade (Out of 20)",
        y = "Cumulative Frequency"
      ) +
      scale_x_continuous(limits = c(0, 20), expand = c(0, 0)) +
      theme_minimal(base_size = 15)
  })
  
###############################################################################3
  
  # Render Q-Q plot for the first semester grades
  output$qqFirstSemPlot <- renderPlot({
    ggplot(processedData(), aes(sample = `Curricular_units_1st_sem_(grade)`)) +
      stat_qq(distribution = function(p) qunif(p, min = 0, max = 20)) +
      stat_qq_line(distribution = function(p) qunif(p, min = 0, max = 20), color = "#355F2E", size = 1) +
      labs(
        title = "Q-Q Plot of First Semester Grades",
        x = "Theoretical Quantiles",
        y = "Sample Quantiles"
      ) +
      theme_minimal(base_size = 15) +
      theme(legend.position = "center")
  })
  
  # Render Q-Q plot for the second semester grades
  output$qqSecondSemPlot <- renderPlot({
    ggplot(processedData(), aes(sample = `Curricular_units_2nd_sem_(grade)`)) +
      stat_qq(distribution = function(p) qunif(p, min = 0, max = 20)) +
      stat_qq_line(distribution = function(p) qunif(p, min = 0, max = 20), color = "#A8CD89", size = 1) +
      labs(
        title = "Q-Q Plot of Second Semester Grades",
        x = "Theoretical Quantiles",
        y = "Sample Quantiles"
      ) +
      theme_minimal(base_size = 15)
  })
  
################################################################################
  # Render the overlay density plot
  output$gradeDistributionPlot <- renderPlot({
    ggplot() +
      geom_density(data = processedData(), aes(x = `Curricular_units_1st_sem_(grade)`, color = "1st Semester"), size = 1) +
      geom_density(data = processedData(), aes(x = `Curricular_units_2nd_sem_(grade)`, color = "2nd Semester"), size = 1) +
      scale_color_manual(
        values = c("1st Semester" = "#85A98F",  # Custom color for 1st Semester
                   "2nd Semester" = "#FDCEDF")  # Custom color for 2nd Semester
      ) +
      labs(
        title = "Comparison of Grade Distributions",
        x = "Grades",
        y = "Density",
        color = "Semester"
      ) +
      theme_minimal(base_size = 15) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text = element_text(size = 12),
        legend.text = element_text(size = 12),
        legend.title = element_text(size = 14)
      )
  })
  
################################################################################
  # Reactive expression to aggregate data by Nationality and Performance
  performanceNationalityData <- reactive({
    req(data)  # Ensure the data is available
    data %>%
      group_by(Nacionality, First_Sem_Performance) %>%
      summarise(Count = n(), .groups = "drop") %>%
      mutate(Percentage = Count / sum(Count) * 100)
  })
  
  # Render the Performance Evaluation by Nationality plot
  output$performanceEvaluationPlot <- renderPlot({
    ggplot(performanceNationalityData(), aes(y = reorder(Nacionality, -Count), x = Percentage, fill = First_Sem_Performance)) +
      geom_bar(stat = "identity", position = "fill", width = 0.8) +
      geom_text(
        aes(label = Count), 
        position = position_fill(vjust = 0.5), 
        size = 2, 
        color = "white"
      ) +
      scale_x_continuous(labels = scales::percent) +
      scale_fill_manual(
        values = c(
          "Failing" = "#C96868",  # Red
          "Passing" = "#D3F1DF",  # Yellow
          "Good" = "#85A98F",     # Green
          "Excellent" = "#5A6C57" # Blue
        )
      ) +
      labs(
        title = "Performance Evaluation by Nationality",
        x = "Percentage",
        y = "Nationality",
        fill = "Performance"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        axis.text.y = element_text(size = 10),
        axis.text.x = element_text(size = 10),
        plot.title = element_text(hjust = 0.5, size = 16),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12)
      )
  })
#########################################################################
  # Reactive expression to prepare the map data
  worldMapData <- reactive({
    req(data)  # Ensure the data is available
    
    # Aggregate data by nationality and map to country names
    map_data <- data %>%
      group_by(Nacionality) %>%
      summarise(Count = n(), .groups = "drop") %>%
      left_join(nationality_mapping, by = "Nacionality")
    
    # Join with world map data
    world_data <- left_join(world, map_data, by = c("name" = "Country"))
    
    # Highlight Portugal and other countries
    world_data %>%
      mutate(
        Highlight = case_when(
          name == "Portugal" ~ "Portugal",
          !is.na(Count) ~ "Students Orgins",
          TRUE ~ "Other"
        )
      ) %>%
      st_transform(crs = "+proj=robin")  # Transform projection to Robinson
  })
  
  # Render the map plot
  output$globalDistributionPlot <- renderPlot({
    ggplot(worldMapData()) +
      geom_sf(aes(fill = Highlight), color = "black", size = 0.2) +  # Add borders
      scale_fill_manual(
        values = c(
          "Portugal" = "#006400",  # Dark green for Portugal
          "Students Orgins" = "#90EE90",  # Light green for other countries
          "Other" = "grey90"  # Grey for other countries
        ),
        name = " "
      ) +
      coord_sf(crs = st_crs("+proj=robin")) +  # Robinson projection
      labs(
        title = "Global Distribution: Highlighted Countries and Enlarged Portugal",
        subtitle = "Portugal is highlighted with larger size for emphasis"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 18),
        plot.subtitle = element_text(hjust = 0.5, size = 12),
        legend.position = "bottom"
      )
  })
###################################################################################
  # Reactive expression for Top 5 Nationalities
  topNationalitiesData <- reactive({
    req(data)  # Ensure the dataset is available
    
    data %>%
      count(Nacionality, sort = TRUE) %>%
      filter(Nacionality != "Portuguese") %>%  # Exclude Portuguese
      top_n(5, n)  # Get the top 5 nationalities
  })
  
  # Render the plot for Top 5 Nationalities
  output$topNationalitiesPlot <- renderPlot({
    ggplot(topNationalitiesData(), aes(x = reorder(Nacionality, n), y = n, fill = Nacionality)) +
      geom_bar(stat = "identity") +
      geom_text(aes(label = n), vjust = -0.3, size = 5) +
      scale_fill_brewer(palette = "Greens") +  # Apply green palette
      ylim(0, max(topNationalitiesData()$n) + 50) +  # Set y-axis limit with padding
      labs(
        title = "Top 5 Nationalities by Number of Students Excluding Portuguese",
        x = "Nationality",
        y = "Number of Students"
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5),
        legend.position = "none"
      )
  })
#################################################################################
  # Server logic for Nationality and Target Plot
  output$targetDistributionPlot <- renderPlot({
    # Aggregate data by Nationality and Target
    nationality_target <- data %>%
      group_by(Nacionality, Target) %>%
      summarise(Count = n(), .groups = 'drop') %>%
      group_by(Nacionality) %>%
      mutate(Total = sum(Count)) %>%
      ungroup() %>%
      mutate(Nacionality = reorder(Nacionality, Total))
    
    # Plot for Nationality and Target
    ggplot(nationality_target, aes(x = Count, y = Nacionality, fill = Target)) +
      geom_bar(stat = "identity", position = "fill", width = 0.7) +
      geom_text(
        aes(label = Count),
        position = position_fill(vjust = 0.5),
        color = "white",
        size = 3.5
      ) +
      labs(
        title = "Target Distribution by Nationality",
        x = "Proportion",
        y = "Nationality",
        fill = "Target"
      ) +
      scale_fill_manual(
        values = c("Graduate" = "#5A6C57", "Dropout" = "#D3F1DF", "Enrolled" = "#85A98F")
      ) +
      theme_minimal(base_size = 14) +
      theme(
        plot.title = element_text(hjust = 0.5, size = 16),
        axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 10),
        legend.text = element_text(size = 10),
        legend.title = element_text(size = 12)
      )
  })
  
  #################################################################################
  

  
  #################################################################################
  
  first_sem_data <- reactive({
    result <- data %>%
      filter(!is.na(Nacionality) & !is.na(`Curricular_units_1st_sem_(grade)`)) %>%
      group_by(Nacionality) %>%
      summarise(
        mean_grade = mean(`Curricular_units_1st_sem_(grade)`, na.rm = TRUE),
        lower_ci = mean_grade - qt(0.9, df = n() - 1) * sd(`Curricular_units_1st_sem_(grade)`, na.rm = TRUE) / sqrt(n()),
        upper_ci = mean_grade + qt(0.9, df = n() - 1) * sd(`Curricular_units_1st_sem_(grade)`, na.rm = TRUE) / sqrt(n())
      )
    print(result)  # Add this for debugging
    result
  })
  
  
  second_sem_data <- reactive({
    result <- data %>%
      filter(!is.na(Nacionality) & !is.na(`Curricular_units_2nd_sem_(grade)`)) %>%
      group_by(Nacionality) %>%
      summarise(
        mean_grade = mean(`Curricular_units_2nd_sem_(grade)`, na.rm = TRUE),
        lower_ci = mean_grade - qt(0.9, df = n() - 1) * sd(`Curricular_units_2nd_sem_(grade)`, na.rm = TRUE) / sqrt(n()),
        upper_ci = mean_grade + qt(0.9, df = n() - 1) * sd(`Curricular_units_2nd_sem_(grade)`, na.rm = TRUE) / sqrt(n())
      )
    print(result)  # Add this for debugging
    result
  })
  
  
  output$uncertaintyFirstSemPlot <- renderPlot({
    plot_data <- first_sem_data()
    print(plot_data)  # Debug: Check the data being passed to ggplot
    ggplot(plot_data, aes(x = reorder(Nacionality, mean_grade), y = mean_grade)) +
      geom_point(size = 3, color = "#85A98F") +
      geom_errorbar(aes(ymin = lower_ci, ymax = upper_ci), width = 0.2, color = "#C96868") +
      coord_flip() +
      labs(
        title = "Mean Grades by Nationality (1st Semester)",
        x = "Nationality",
        y = "Mean Grade"
      ) +
      theme_minimal()+
      theme(
        plot.title = element_text(face = "bold", size = 20),  # Bold and bigger title

      )
  })
  
  
  
  output$uncertaintySecondSemPlot <- renderPlot({
    plot_data <- second_sem_data()
    print(plot_data)  # Debug: Check the data being passed to ggplot
    ggplot(plot_data, aes(x = reorder(Nacionality, mean_grade), y = mean_grade)) +
      geom_point(size = 3, color = "#85A98F") +
      geom_errorbar(aes(ymin = lower_ci, ymax = upper_ci), width = 0.2, color = "#C96868") +
      coord_flip() +
      labs(
        title = "Mean Grades by Nationality (2nd Semester)",
        x = "Nationality",
        y = "Mean Grade"
      ) +
      theme_minimal()+
    theme(
      plot.title = element_text(face = "bold", size = 20),  # Bold and bigger title

    )
  })
  
  
  #################################################################################



    
    # Ensure the column names match your dataset structure
    colnames(data) <- gsub("\\.", " ", colnames(data))  # Replace "." with spaces if needed
    
    # Categorize performance into "Failure" and "Success"
    data <- data %>%
      mutate(
        First_Sem_Category = ifelse(First_Sem_Performance == "Failing", "Failure", "Success"),
        Second_Sem_Category = ifelse(Second_Sem_Performance == "Failing", "Failure", "Success")
      )
    
    # Create percentages for First Semester
    first_sem_summary <- data %>%
      count(First_Sem_Category) %>%
      mutate(
        Percentage = round(n / sum(n) * 100),
        Grid = list(rep(First_Sem_Category, Percentage))
      ) %>%
      unnest(cols = c(Grid))
    
    # Randomize the grid for First Semester
    first_sem_grid <- data.frame(
      Rows = rep(1:10, each = 10),
      Cols = rep(1:10, times = 10),
      Fill = sample(first_sem_summary$Grid[1:100])  # Shuffle the Fill values
    )
    
    # Create percentages for Second Semester
    second_sem_summary <- data %>%
      count(Second_Sem_Category) %>%
      mutate(
        Percentage = round(n / sum(n) * 100),
        Grid = list(rep(Second_Sem_Category, Percentage))
      ) %>%
      unnest(cols = c(Grid))
    
    # Randomize the grid for Second Semester
    second_sem_grid <- data.frame(
      Rows = rep(1:10, each = 10),
      Cols = rep(1:10, times = 10),
      Fill = sample(second_sem_summary$Grid[1:100])  # Shuffle the Fill values
    )
    
    # Render First Semester Plot
    output$firstSemGridPlot <- renderPlot({
      ggplot(first_sem_grid, aes(x = Cols, y = Rows, fill = Fill)) +
        geom_tile(color = "white") +
        scale_fill_manual(values = c("Failure" = "#C96868", "Success" = "#85A98F")) +
        labs(
          title = "First Semester Performance: 16% of Students Struggle to Succeed",
          x = "Student (Grid Columns)",
          y = "Student (Grid Rows)"
        ) +
        theme_minimal() +
        theme(
          plot.title = element_text(face = "bold", size = 20),  # Bold and bigger title
          axis.text = element_blank(),
          axis.ticks = element_blank(),
          panel.grid = element_blank()
        )
    })
    
    # Render Second Semester Plot
    output$secondSemGridPlot <- renderPlot({
      ggplot(second_sem_grid, aes(x = Cols, y = Rows, fill = Fill)) +
        geom_tile(color = "white") +
        scale_fill_manual(values = c("Failure" = "#C96868", "Success" = "#85A98F")) +
        labs(
          title = "Second Semester Performance: 20% of Students Struggle to Succeed",
          x = "Student (Grid Columns)",
          y = "Student (Grid Rows)"
        ) +
        theme_minimal() +
        theme(
          plot.title = element_text(face = "bold", size = 20),  # Bold and bigger title
          axis.text = element_blank(),
          axis.ticks = element_blank(),
          panel.grid = element_blank()
        )
      
    })
  
  #################################################################################
  
}

# Run the application
shinyApp(ui = ui, server = server)
